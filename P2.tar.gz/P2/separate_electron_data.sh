#!/bin/bash

data_dir=/root/Desktop/host/P2/Problem1/electron_scattering_data
regex='index_([0-9]+)\.bin'

cd $data_dir
mkdir -p even odd

for file in *; do
    # Extract the index from the filename using regex
    index=$(echo "$file" | grep -oP '(?<=index_)[0-9]+')
    if (( index % 2 == 0 )); then
        mv "$file" /electron_scattering_data/even/
    else
        mv "$file" /electron_scattering_data/odd/
    fi
done